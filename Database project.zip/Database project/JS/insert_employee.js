document.addEventListener("DOMContentLoaded", function () {
    const insertEmployeeForm = document.querySelector('#insert-employee-form');
    const message = document.getElementById('message');
    const residenceNameSelect = document.getElementById("ResidenceNo");
    const employeeTable = document.getElementById("employee-table");

    function loadResidenceNames() {
        fetch("../PHP/insert_employee.php?getResidenceNames=true")
            .then((response) => response.json())
            .then((data) => {
                data.forEach((residenceNo) => {
                    const option = document.createElement("option");
                    option.value = residenceNo;
                    option.textContent = residenceNo;
                    residenceNameSelect.appendChild(option);
                });
            });
    }

    function loadEmployees() {
        fetch("../PHP/insert_employee.php?getEmployees=true")
            .then((response) => response.json())
            .then((data) => {
                data.forEach((employee) => {
                    const row = employeeTable.insertRow();
                    row.innerHTML = `<td>${employee.FirstName}</td><td>${employee.LastName}</td><td>${employee.occupation}</td><td>${employee.ResidenceNo}</td>`;
                });
            });
    }

    loadResidenceNames();
    loadEmployees();

    insertEmployeeForm.addEventListener("submit", function (event) {
        event.preventDefault();

        const formData = new FormData(insertEmployeeForm);
        fetch("../PHP/insert_employee.php", {
            method: "POST",
            body: formData,
        })
            .then((response) => response.text())
            .then((data) => {
                message.textContent = data;
                clearForm(insertEmployeeForm);
                loadEmployees(); // Load employees after inserting
            })
            .catch((error) => {
                console.error("Error:", error);
            });
    });

    function clearForm(form) {
        form.reset();
        message.textContent = "";
    }
});
