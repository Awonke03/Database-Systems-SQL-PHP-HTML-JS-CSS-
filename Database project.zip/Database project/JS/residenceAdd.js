document.addEventListener("DOMContentLoaded", () => {
    loadResidences();

    document.getElementById("addResidenceForm").addEventListener("submit", (event) => {
        event.preventDefault();
        const formData = new FormData(event.target);
        addResidence(formData);
    });

    document.getElementById("deleteResidenceForm").addEventListener("submit", (event) => {
        event.preventDefault();
        const formData = new FormData(event.target);
        deleteResidence(formData.get("ResidenceNo"));
    });
});

function loadResidences() {
    fetch("../PHP/server.php?getResidences=true")
        .then((response) => response.json())
        .then((data) => {
            const table = document.querySelector("table");
            table.innerHTML = "<tr><th>Residence No</th><th>Residence Name</th><th>Street Address</th><th>City</th><th>Province</th><th>Postal Code</th></tr>";

            data.forEach((residence) => {
                const row = table.insertRow();
                row.innerHTML = `<td>${residence.ResidenceNo}</td><td>${residence.ResidenceName}</td><td>${residence.streetAddress}</td><td>${residence.city}</td><td>${residence.province}</td><td>${residence.postal_code}</td>`;
            });
        });
}

function addResidence(formData) {
    fetch("../PHP/server.php", {
        method: "POST",
        body: formData,
    })
    .then((response) => response.text())
    .then((message) => {
        alert(message);
        loadResidences();
    });
}
