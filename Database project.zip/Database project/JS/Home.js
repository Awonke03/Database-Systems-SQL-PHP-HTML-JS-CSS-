document.addEventListener("DOMContentLoaded", function () {
    var usernameElement = document.getElementById("username");
    var privilegesElement = document.getElementById("privileges");
    var alertButton = document.getElementById("alertButton");

    usernameElement.textContent = username;

    if (role === 'admin') {
        privilegesElement.textContent = "You have admin privileges.";
    } else {
        privilegesElement.textContent = "You have user privileges.";
    }

    alertButton.addEventListener("click", function () {
        alert("Hello, " + username + "!");
    });
});
