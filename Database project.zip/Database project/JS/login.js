document.getElementById('signin-form').addEventListener('submit', function(event) {
    event.preventDefault();

    var studentNumber = document.getElementById('student_number').value;
    var pin = document.getElementById('pin').value;

    var xhr = new XMLHttpRequest();
    xhr.open('POST', '../php/login.php', true);
    xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');

    xhr.onload = function() {
        if (xhr.status >= 200 && xhr.status < 400) {
            var response = JSON.parse(xhr.responseText);
            if (response.success) {
                // Redirect to status.html with student number as a query parameter
                window.location.href = '../php/status.php?studentNo=' + studentNumber;
            } else {
                alert('Invalid credentials. Please try again.');
            }
        } else {
            console.error('Server error');
        }
    };

    xhr.onerror = function() {
        console.error('Connection error');
    };

    var data = 'student_number=' + encodeURIComponent(studentNumber) + '&pin=' + encodeURIComponent(pin);

    xhr.send(data);
});
