document.addEventListener("DOMContentLoaded", function () {
    const insertEmployeeForm = document.querySelector('#insert-employee-form');
    const deleteEmployeeForm = document.querySelector('#delete-employee-form');
    const message = document.getElementById('message');

    insertEmployeeForm.addEventListener("submit", function (event) {
        event.preventDefault();

        const formData = new FormData(insertEmployeeForm);
        fetch("../php/insert_employee.php", {
            method: "POST",
            body: formData,
        })
            .then((response) => response.text())
            .then((data) => {
                message.textContent = data;
                clearForm(insertEmployeeForm);
            })
            .catch((error) => {
                console.error("Error:", error);
            });
    });

    deleteEmployeeForm.addEventListener("submit", function (event) {
        event.preventDefault();

        const formData = new FormData(deleteEmployeeForm);
        fetch("../php/delete_employee.php", {
            method: "POST",
            body: formData,
        })
            .then((response) => response.text())
            .then((data) => {
                message.textContent = data;
                clearForm(deleteEmployeeForm);
            })
            .catch((error) => {
                console.error("Error:", error);
            });
    });

    function clearForm(form) {
        form.reset();
        message.textContent = "";
    }
});
