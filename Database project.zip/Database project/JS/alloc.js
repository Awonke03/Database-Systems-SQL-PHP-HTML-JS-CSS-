document.addEventListener("DOMContentLoaded", () => {
    let selectedApplicationNo;
    let selectedRoomNo;

    // Fetch data from the PHP script
    fetch("../PHP/display_table.php")
        .then((response) => response.json())
        .then((data) => {
            // Display the Applications table
            displayTable("applicationsTable", data.applications);

            // Populate the ApplicationNo dropdown
            populateDropdown("applicationDropdown", data.applications, "ApplicationNo");

            // Display the Rooms table
            displayTable("roomsTable", data.rooms);

            // Populate the RoomNo dropdown
            populateDropdown("roomDropdown", data.rooms, "RoomNo");
        });

    document.getElementById("applicationDropdown").addEventListener("change", (event) => {
        selectedApplicationNo = event.target.value;
    });

    document.getElementById("roomDropdown").addEventListener("change", (event) => {
        selectedRoomNo = event.target.value;
    });

    document.getElementById("acceptButton").addEventListener("click", () => {
        if (selectedApplicationNo && selectedRoomNo) {
            acceptApplication(selectedApplicationNo, selectedRoomNo);
        } else {
            alert("Please select an Application and a Room from the dropdowns.");
        }
    });
});

function displayTable(tableId, data) {
    const table = document.getElementById(tableId);
    if (data.length > 0) {
        const headerRow = table.insertRow(0);
        for (const key in data[0]) {
            const headerCell = document.createElement("th");
            headerCell.textContent = key;
            headerRow.appendChild(headerCell);
        }

        data.forEach((row) => {
            const newRow = table.insertRow(-1);
            for (const key in row) {
                const newCell = newRow.insertCell(-1);
                newCell.textContent = row[key];
            }
        });
    } else {
        table.innerHTML = "No data available.";
    }
}

function populateDropdown(selectId, data, key) {
    const dropdown = document.getElementById(selectId);
    data.forEach((row) => {
        const option = document.createElement("option");
        option.value = row[key];
        option.textContent = row[key];
        dropdown.appendChild(option);
    });
}

function acceptApplication(applicationNo, roomNo) {
    fetch("../PHP/update_app_status_and_room.php", {
        method: "POST",
        body: JSON.stringify({ applicationNo, roomNo }),
        headers: {
            "Content-Type": "application/json",
        },
    })
    .then((response) => response.json())
    .then((data) => {
        if (data.success) {
            alert("Application accepted successfully.");
            location.reload(); // Reload the page to update the dropdowns
        } else {
            alert("Error accepting application.");
        }
    });
}
