function retrieveStudentData() {
    const idNumber = document.getElementById("idNumber").value;

    fetch(`../php/forgot_pin.php?idNumber=${idNumber}`)
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                const studentData = data.student;
                const studentInfo = `Student Number: ${studentData.studentno}\nPIN: ${studentData.pin}`;
                alert(studentInfo);
            } else {
                alert("Student not found or an error occurred.");
            }
        })
        .catch(error => {
            alert("An error occurred while retrieving data.");
        });
}
