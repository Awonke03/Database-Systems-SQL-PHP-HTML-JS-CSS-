document.addEventListener("DOMContentLoaded", () => {
    loadBuildings();
    loadResidenceOptions();

    document.getElementById("addBuildingForm").addEventListener("submit", (event) => {
        event.preventDefault();
        const formData = new FormData(event.target);
        addBuilding(formData);
    });

    document.getElementById("deleteBuildingForm").addEventListener("submit", (event) => {
        event.preventDefault();
        const formData = new FormData(event.target);
        deleteBuilding(formData.get("BuildingNo"));
    });
});

function loadBuildings() {
    const buildingTable = document.querySelector("table");
    buildingTable.innerHTML = "<tr><th>Building No</th><th>Capacity</th><th>Residence No</th></tr>";

    fetch("../PHP/buildings.php?getBuildings=true")
        .then((response) => response.json())
        .then((data) => {
            data.forEach((building) => {
                const row = buildingTable.insertRow();
                row.innerHTML = `<td>${building.BuildingNo}</td><td>${building.Capacity}</td><td>${building.ResidenceNo}</td>`;
            });
        });
}

function loadResidenceOptions() {
    const residenceSelect = document.getElementById("ResidenceNo");
    fetch("../PHP/buildings.php?getResidence=true")
        .then((response) => response.json())
        .then((data) => {
            data.forEach((residence) => {
                const option = document.createElement("option");
                option.value = residence.ResidenceNo;
                option.textContent = residence.ResidenceNo;
                residenceSelect.appendChild(option);
            });
        });
}

function addBuilding(formData) {
    fetch("../PHP/buildings.php", {
        method: "POST",
        body: formData,
    })
    .then((response) => response.text())
    .then((message) => {
        alert(message);
        loadBuildings();
    });
}

function deleteBuilding(BuildingNo) {
    fetch("../PHP/buildings.php?deleteBuilding=" + BuildingNo, {
        method: "DELETE",
    })
    .then((response) => response.text())
    .then((message) => {
        alert(message);
        loadBuildings();
    });
}
