document.addEventListener("DOMContentLoaded", function () {
    // Get the student data from the URL
    const urlParams = new URLSearchParams(window.location.search);
    const studentNumber = urlParams.get("studentNo");

    // Fetch student data using an HTTP request
    fetch(`../php/status.php?studentNo=${studentNumber}`)
        .then(response => response.json())
        .then(data => {
            document.getElementById("student_number").textContent = data.StudentNo;
            document.getElementById("title").textContent = data.Title;
            document.getElementById("last_name").textContent = data.LastName;
            document.getElementById("first_name").textContent = data.FirstName;
            document.getElementById("id").textContent = data.ID_No;
            document.getElementById("gender").textContent = data.Gender;
            document.getElementById("app_status").textContent = data.AppStatus;
            document.getElementById("app_date").textContent = data.ApplDate;
            document.getElementById("room_no").textContent = data.RoomNo;
            document.getElementById("building_no").textContent = data.BuildingNo;
            document.getElementById("residence_name").textContent = data.ResidenceName;
        })
        .catch(error => {
            console.error("Error fetching student data:", error);
        });

    // Add event listener to the label
    const viewAllocationLabel = document.getElementById("view_allocation");
    viewAllocationLabel.addEventListener("click", function () {
        const modal = document.getElementById("myModal");
        modal.style.display = "block";
    });

    // Add event listener to close the modal
    const closeBtn = document.getElementsByClassName("close")[0];
    closeBtn.addEventListener("click", function () {
        const modal = document.getElementById("myModal");
        modal.style.display = "none";
    });
});
