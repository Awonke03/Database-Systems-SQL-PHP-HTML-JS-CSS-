document.addEventListener("DOMContentLoaded", () => {
    loadTables();
});

function loadTables() {
    // Fetch data for applications and rooms from the server
    fetch("../PHP/display_tables.php")
        .then((response) => response.json())
        .then((data) => {
            const applicationDropdown = document.getElementById("applicationDropdown");
            const roomDropdown = document.getElementById("roomDropdown");
            const applicationsTable = document.getElementById("applicationsTable");
            const roomsTable = document.getElementById("roomsTable");

            applicationDropdown.innerHTML = ""; // Clear the dropdown
            roomDropdown.innerHTML = ""; // Clear the dropdown
            applicationsTable.innerHTML = ""; // Clear the table
            roomsTable.innerHTML = ""; // Clear the table

            populateDropdown(applicationDropdown, data.applications, "ApplicationNo");
            populateDropdown(roomDropdown, data.rooms, "RoomNo");
            displayTable(applicationsTable, data.applications);
            displayTable(roomsTable, data.rooms);
        });
}

function populateDropdown(dropdown, data, valueField) {
    for (const item of data) {
        const option = document.createElement("option");
        option.text = item[valueField];
        option.value = item[valueField];
        dropdown.add(option);
    }
}

function displayTable(table, data) {
    const headerRow = table.insertRow();
    for (const key in data[0]) {
        if (data[0].hasOwnProperty(key)) {
            const headerCell = document.createElement("th");
            headerCell.innerHTML = key;
            headerRow.appendChild(headerCell);
        }
    }

    for (const item of data) {
        const row = table.insertRow();
        for (const key in item) {
            if (item.hasOwnProperty(key)) {
                const cell = row.insertCell();
                cell.innerHTML = item[key];
            }
        }
    }
}

function acceptApplication() {
    const applicationDropdown = document.getElementById("applicationDropdown");
    const roomDropdown = document.getElementById("roomDropdown");
    const selectedApplication = applicationDropdown.value;
    const selectedRoom = roomDropdown.value;

    if (!selectedApplication || !selectedRoom) {
        alert("Please select an application and a room.");
        return;
    }

    // Send the selected application and room to the server for acceptance
    fetch("../PHP/update_app_status_and_room.php", {
        method: "POST",
        body: JSON.stringify({ applicationNo: selectedApplication, roomNo: selectedRoom }),
        headers: {
            "Content-Type": "application/json",
        },
    })
        .then((response) => response.json())
        .then((data) => {
            if (data.success) {
                alert("Application accepted successfully.");
                loadTables(); // Reload tables after accepting an application
            } else {
                alert("Error accepting application.");
            }
        });
}
