document.addEventListener("DOMContentLoaded", function () {
    const form = document.querySelector("form");

    form.addEventListener("submit", function (event) {
        event.preventDefault(); // Prevent the form from submitting to check validation

        // Reset error messages and styles
        const errorMessages = form.querySelectorAll(".error-message");
        errorMessages.forEach(errorMsg => errorMsg.textContent = '');

        let hasError = false;
        let requiredFieldsMessage = "Fields in red are required:\n";

        // Define validation functions
        function showError(input, message) {
            if (input.type !== "submit") {
                input.style.border = "1px solid red";
                hasError = true;
                requiredFieldsMessage += `${input.placeholder}\n`;
            }
        }

        function resetError(input) {
            input.style.border = "1px solid #ccc";
        }

        const inputs = form.querySelectorAll("input");

        inputs.forEach((input) => {
            resetError(input);
            if (input.value.trim() === "" && input.type !== "submit") {
                showError(input, "This field is required.");
            }
        });

        const idNumber = form.querySelector("input[name='id_number']");
        if (!/^\d{13}$/.test(idNumber.value)) {
            showError(idNumber, "ID Number should be numeric and exactly 13 digits.");
        }

        const cellNumber = form.querySelector("input[name='cell_number']");
        if (!/^0[6-8]\d{8}$/.test(cellNumber.value)) {
            showError(cellNumber, "Cell Phone Number should start with '0' and be followed by 9 digits with the second digit between 6 and 8.");
        }

        // Check if any errors occurred
        if (hasError) {
            alert(requiredFieldsMessage);
        } else {
            // If no errors, submit the form
            form.submit();
        }
    });
    
    // Display a pop-up message
    const urlParams = new URLSearchParams(window.location.search);
    const successMessage = urlParams.get('success');
    if (successMessage) {
        alert("Record has been saved successfully.");

        // Automatically redirect to the new URL after displaying the success pop-up
        setTimeout(function() {
            window.location.href = "../html/confirmation.html";
        }, 3000); // Redirect after 3 seconds (adjust the delay as needed)
    }
});
