document.addEventListener("DOMContentLoaded", () => {
    loadRooms();
    populateBuildingNoDropdown();

    document.getElementById("addRoomForm").addEventListener("submit", (event) => {
        event.preventDefault();
        const formData = new FormData(event.target);
        addRoom(formData);
        event.target.reset();
    });
});

function loadRooms() {
    const roomTable = document.querySelector("#roomTable");
    roomTable.innerHTML = "<tr><th>Room No</th><th>Status</th><th>Room Type</th><th>Building No</th></tr>";

    fetch("../PHP/rooms.php?getRooms=true")
        .then((response) => response.json())
        .then((data) => {
            data.forEach((room) => {
                const row = roomTable.insertRow();
                const status = room.Status === "0" ? "Not Available" : "Available";
                row.innerHTML = `<td>${room.RoomNo}</td><td>${status}</td><td>${room.Room_Type}</td><td>${room.BuildingNo}</td>`;
            });
        });
}

function addRoom(formData) {
    fetch("../PHP/rooms.php", {
        method: "POST",
        body: formData,
    })
    .then((response) => response.text())
    .then((message) => {
        alert(message);
        loadRooms();
    });
}

function populateBuildingNoDropdown() {
    const buildingNoDropdown = document.getElementById("buildingNoDropdown");
    fetch("../PHP/rooms.php?getBuildingNumbers=true")
        .then((response) => response.json())
        .then((data) => {
            data.forEach((buildingNo) => {
                const option = document.createElement("option");
                option.value = buildingNo.BuildingNo;
                option.textContent = buildingNo.BuildingNo;
                buildingNoDropdown.appendChild(option);
            });
        });
}
