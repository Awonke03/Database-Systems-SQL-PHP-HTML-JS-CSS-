function redirectToHome() {
    window.location.href = "../html/home.html";
    document.getElementById("redirect-message").innerText = "Redirecting to Home...";
}

function redirectToLogin() {
    window.location.href = "../html/login.html";
    document.getElementById("redirect-message").innerText = "Redirecting to Login...";
}

document.getElementById("homeButton").addEventListener("click", redirectToHome);
document.getElementById("loginButton").addEventListener("click", redirectToLogin);
