function deleteStudent() {
    var studentNo = document.getElementById("studentNo").value;

    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4) {
            if (xhr.status === 200) {
                document.getElementById("message").innerHTML = xhr.responseText;
            } else {
                document.getElementById("message").innerHTML = "Error: " + xhr.status;
            }
        }
    };

    xhr.open("POST", "../PHP/delete_student.php", true);
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhr.send("studentNo=" + studentNo);
}
