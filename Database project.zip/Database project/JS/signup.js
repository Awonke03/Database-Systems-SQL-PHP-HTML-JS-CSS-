document.addEventListener("DOMContentLoaded", function () {
    const form = document.getElementById("signup-form");

    form.addEventListener("submit", function (event) {
        event.preventDefault();
        let hasError = false;
        const inputs = form.querySelectorAll("input[type='text'], input[type='password']");

        const errorMessages = form.querySelectorAll(".error-message");
        errorMessages.forEach(errorMsg => errorMsg.textContent = '');

        inputs.forEach((input) => {
            if (input.value.trim() === "") {
                input.style.border = "1px solid red";
                hasError = true;

                const errorMsg = document.getElementById(input.id + "_error");
                errorMsg.textContent = "This field is required.";
            } else {
                input.style.border = "1px solid #ccc";
            }
        });

        const pin = document.getElementById("pin").value;
        if (!/^\d{5}$/.test(pin)) {
            document.getElementById("pin").style.border = "1px solid red";
            hasError = true;

            const errorMsg = document.getElementById("pin_error");
            errorMsg.textContent = "PIN must be 5 numeric digits.";
        }

        const cell_phone = document.getElementById("cell_phone").value;
        if (!/^0[6-8]\d{8}$/.test(cell_phone)) {
            document.getElementById("cell_phone").style.border = "1px solid red";
            hasError = true;

            const errorMsg = document.getElementById("cell_phone_error");
            errorMsg.textContent = "Cell Phone Number should start with '0' and have the second digit between 6 and 8.";

            // Display a pop-up error message
            alert("Cell Phone Number should start with '0' and have the second digit between 6 and 8.");
        }

      

        const student_number = document.getElementById("student_number").value;
        if (!/^\d{9}$/.test(student_number)) {
            document.getElementById("student_number").style.border = "1px solid red";
            hasError = true;

            const errorMsg = document.getElementById("student_number_error");
            errorMsg.textContent = "Student Number should be a 9-digit number.";
        }

        const id_number = document.getElementById("id_number").value;
        if (!/^\d{13}$/.test(id_number)) {
            document.getElementById("id_number").style.border = "1px solid red";
            hasError = true;

            const errorMsg = document.getElementById("id_number_error");
            errorMsg.textContent = "ID Number should be a 13-digit number.";
        }

        if (hasError) {
            alert("Please correct the highlighted fields.");
        } else {
            form.submit();
        }
    });
});
