DROP SCHEMA IF EXISTS ResApplications;
CREATE SCHEMA ResApplications;
USE ResApplications;

CREATE TABLE Residence (
    ResidenceNo INT AUTO_INCREMENT PRIMARY KEY,
    ResidenceName VARCHAR(30),
    streetAddress VARCHAR(20),
    city VARCHAR(20),
    province VARCHAR(20),
    postal_code VARCHAR(4)
);

CREATE TABLE Building (
    BuildingNo INT AUTO_INCREMENT PRIMARY KEY,
    Capacity INT,
    ResidenceNo INT,
    FOREIGN KEY (ResidenceNo) REFERENCES Residence(ResidenceNo)
);

CREATE TABLE Rooms (
    RoomNo INT AUTO_INCREMENT PRIMARY KEY,
    Status BOOLEAN,
    Room_Type VARCHAR(12),
    BuildingNo INT,
    FOREIGN KEY (BuildingNo) REFERENCES Building(BuildingNo)
);

CREATE TABLE Applications (
    ApplicationNo INT AUTO_INCREMENT PRIMARY KEY,
    ApplDate DATE,
    AppStatus VARCHAR(20) DEFAULT 'Under Review',
    RoomNo INT,
    FOREIGN KEY (RoomNo) REFERENCES Rooms(RoomNo)
);

CREATE TABLE Students (
    StudentNo  INT AUTO_INCREMENT PRIMARY KEY,
    Title VARCHAR(5),
    FirstName VARCHAR(30) NOT NULL,
    LastName VARCHAR(30) NOT NULL,
    ID_No VARCHAR(13) NOT NULL,
    Gender VARCHAR(6),
    cell_number VARCHAR(10) NOT NULL,
    email VARCHAR(50) NOT NULL, 
    ApplicationNo INT,
    pin VARCHAR(6),
    FOREIGN KEY (ApplicationNo) REFERENCES Applications(ApplicationNo)
);

CREATE TABLE Nextofkin (
    NokNO INT AUTO_INCREMENT PRIMARY KEY,
    title varchar(4),
    FirstName VARCHAR(30) NOT NULL,
    LastName VARCHAR(30) NOT NULL,
    ID_No VARCHAR(13) NOT NULL,
    Gender VARCHAR(1),
    cell_number VARCHAR(10) NOT NULL,
    email VARCHAR(50) NOT NULL, 
    Relationship VARCHAR(20), 
    StudentNo int, 
    FOREIGN KEY (StudentNo) REFERENCES Students(StudentNo)
);

CREATE TABLE Employees (
    EmployeeNo INT AUTO_INCREMENT PRIMARY KEY,
    Title VARCHAR(5),
    FirstName VARCHAR(30) NOT NULL,
    LastName VARCHAR(30) NOT NULL,
    ID_No VARCHAR(13) NOT NULL,
    Gender VARCHAR(6),
    cell_number VARCHAR(10) NOT NULL,
    email VARCHAR(50) NOT NULL, 
    occupation VARCHAR(30) NOT NULL,
    ResidenceNo int,
    Foreign key(ResidenceNo) references Residence(ResidenceNO)
);
