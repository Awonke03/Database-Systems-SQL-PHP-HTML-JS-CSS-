<?php
$servername = "localhost";
$username = "Awonke";
$password = "!Wowo@0823";
$dbname = "resapplications";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_GET["getRooms"])) {
    $rooms = getRooms();
    echo json_encode($rooms);
} elseif (isset($_GET["getBuildingNumbers"])) {
    $buildingNumbers = getBuildingNumbers();
    echo json_encode($buildingNumbers);
}

function getRooms() {
    global $conn;
    $sql = "SELECT RoomNo, Status, Room_Type, BuildingNo FROM rooms";
    $result = $conn->query($sql);
    $rooms = [];

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $rooms[] = $row;
        }
    }

    return $rooms;
}

function getBuildingNumbers() {
    global $conn;
    $sql = "SELECT BuildingNo FROM building";
    $result = $conn->query($sql);
    $buildingNumbers = [];

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $buildingNumbers[] = $row;
        }
    }

    return $buildingNumbers;
}

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["Room_Type"]) && isset($_POST["BuildingNo"])) {
    $data = $_POST;
    $result = addRoom($data);
    echo $result;
}

function addRoom($data) {
    global $conn;
    $availability = ($data["Room_Type"] == "Sharing") ? 2 : 1;
    $stmt = $conn->prepare("INSERT INTO rooms (Status, Room_Type, BuildingNo) VALUES (?, ?, ?)");
    $stmt->bind_param("iss", $availability, $data["Room_Type"], $data["BuildingNo"]);

    if ($stmt->execute()) {
        return "Room added successfully.";
    } else {
        return "Error adding room.";
    }
}

$conn->close();
?>
