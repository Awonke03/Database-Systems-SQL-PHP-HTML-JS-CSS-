<?php
$servername = "localhost";
$username = "Awonke";
$password = "!Wowo@0823";
$dbname = "resapplications";

// Create a database connection
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] === "GET") {
    $residences = getResidences();
    echo json_encode($residences);
} elseif ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["ResidenceName"])) {
    $data = $_POST;
    echo addResidence($data);
} elseif ($_SERVER["REQUEST_METHOD"] === "DELETE" && isset($_GET["deleteResidence"])) {
    $ResidenceNo = $_GET["deleteResidence"];
    echo deleteResidence($ResidenceNo);
}


function getResidences() {
    global $conn;
    $sql = "SELECT * FROM residence";
    $result = $conn->query($sql);
    $residences = [];

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $residences[] = $row;
        }
    }

    return $residences;
}

// Function to add a residence to the database

function addResidence($data) {
    global $conn;
    $stmt = $conn->prepare("INSERT INTO residence (ResidenceName, streetAddress, city, province, postal_code) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $data["ResidenceName"], $data["streetAddress"], $data["city"], $data["province"], $data["postal_code"]);

    if ($stmt->execute()) {
        return "Residence added successfully.";
    } else {
        return "Error adding residence.";
    }
}

// Function to delete a residence from the database
function deleteResidence($ResidenceNo) {
    global $conn;
    $stmt = $conn->prepare("DELETE FROM residence WHERE ResidenceNo = ?");
    $stmt->bind_param("i", $ResidenceNo);

    if ($stmt->execute()) {
        return "Residence deleted successfully.";
    } else {
        return "Error deleting residence.";
    }
}


$conn->close();
?>
