<?php

$servername = "localhost";
$username = "Awonke";
$password = "!Wowo@0823";
$dbname = "resapplications";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$inputJSON = file_get_contents('php://input');
$inputData = json_decode($inputJSON);

if ($inputData) {
    $applicationNo = $inputData->applicationNo;
    $roomNo = $inputData->roomNo;

    $conn->begin_transaction();

    $updateAppStatusSql = "UPDATE applications SET AppStatus = 'Accepted' WHERE ApplicationNo = $applicationNo";
    $updateRoomNoSql = "UPDATE applications SET RoomNo = '$roomNo' WHERE ApplicationNo = $applicationNo";
    $reduceStatusSql = "UPDATE rooms SET Status = Status - 1 WHERE RoomNo = '$roomNo'";

    $success = true;

    if (!$conn->query($updateAppStatusSql) || !$conn->query($updateRoomNoSql) || !$conn->query($reduceStatusSql)) {
        $success = false;
    }

    if ($success) {
        $conn->commit();
        echo json_encode(["success" => true]);
    } else {
        $conn->rollback();
        echo json_encode(["success" => false]);
    }
} else {
    echo json_encode(["success" => false]);
}

$conn->close();
