<?php
// Establish a database connection (replace with your database connection details)
$servername = "localhost";
$username = "Awonke";
$password = "!Wowo@0823";
$dbname = "resapplications";

$conn = new mysqli($servername, $username, $password, $dbname);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if ($_SERVER["REQUEST_METHOD"] === "GET") {
    // Retrieve the list of available rooms
    $query = "SELECT Roomno FROM Rooms WHERE available = 0";
    $result = mysqli_query($conn, $query);

    $rooms = array();
    while ($row = mysqli_fetch_assoc($result)) {
        $rooms[] = $row;
    }

    echo json_encode($rooms);
} elseif ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Retrieve the selected room number from the POST request
    $data = json_decode(file_get_contents("php://input"));
    $selectedRoom = $data->roomNo;

    // Find the smallest ApplicationNo where Roomno is NULL
    $query = "SELECT ApplicationNo FROM Applications WHERE Roomno IS NULL ORDER BY ApplicationNo LIMIT 1";
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_assoc($result);
    $applicationNo = $row["ApplicationNo"];

    if ($applicationNo) {
        // Update the selected application with the room number and change AppStatus to Allocated
        $updateQuery = "UPDATE Applications SET Roomno = '$selectedRoom', AppStatus = 'Allocated' WHERE ApplicationNo = $applicationNo";
        $updateResult = mysqli_query($conn, $updateQuery);

        // Update the selected room's availability to 1
        $updateRoomQuery = "UPDATE Rooms SET available = 1 WHERE Roomno = '$selectedRoom'";
        $updateRoomResult = mysqli_query($conn, $updateRoomQuery);

        if ($updateResult && $updateRoomResult) {
            echo json_encode(["success" => true]);
        } else {
            echo json_encode(["success" => false]);
        }
    } else {
        echo json_encode(["success" => false]);
    }
}

mysqli_close($conn);
?>
