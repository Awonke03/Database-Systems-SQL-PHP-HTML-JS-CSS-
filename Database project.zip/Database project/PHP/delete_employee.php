<?php
$servername = "localhost";
$username = "Awonke";
$password = "!Wowo@0823";
$dbname = "resapplications";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST['EmployeeNo'])) {
    $employeeNo = $_POST['EmployeeNo'];

    // Use prepared statement to prevent SQL injection
    $stmt = $conn->prepare("DELETE FROM employees WHERE EmployeeNo = ?");
    $stmt->bind_param("i", $employeeNo); // "i" indicates an integer parameter

    if ($stmt->execute()) {
        echo "Employee deleted successfully.";
        echo '<br><a href="../HTML/AdminPage.html">Go back to home</a>';
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}

$conn->close();
?>
