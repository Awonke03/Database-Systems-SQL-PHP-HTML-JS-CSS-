<?php

$servername = "localhost";
$username = "Awonke";
$password = "!Wowo@0823";
$dbname = "resapplications";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch applications and rooms data from the database
$applications = getApplications($conn);
$rooms = getRooms($conn);

$data = [
    "applications" => $applications,
    "rooms" => $rooms,
];

echo json_encode($data);

$conn->close();

function getApplications($conn) {
    $sql = "SELECT * FROM applications where roomNo=0 and AppStatus ='Under review' ";
    $result = $conn->query($sql);
    $applications = [];

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $applications[] = $row;
        }
    }

    return $applications;
}

function getRooms($conn) {
    $sql = "SELECT * FROM rooms where Status >0";
    $result = $conn->query($sql);
    $rooms = [];

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $rooms[] = $row;
        }
    }

    return $rooms;
}
