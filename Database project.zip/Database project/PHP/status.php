<?php
$servername = "localhost";
$username = "Thurlo";
$password = "1M2@3r4i5t6z";
$dbname = "resapplications";

$conn = new mysqli($servername, $username, $password, $dbname);
$st="";
function getstatus($studentNumber,$conn)
{
    $sql1 = "SELECT students.Title, students.LastName, students.FirstName, 
        students.ID_No, students.StudentNo, students.Gender, applications.AppStatus, applications.ApplDate
        FROM students
        JOIN applications ON students.ApplicationNo = applications.ApplicationNo 
        WHERE students.StudentNo = $studentNumber";
        $a= $conn->query($sql1);
        if ($a->num_rows > 0) {
            $studentD = $a->fetch_assoc();
           return  $studentD["AppStatus"];
        }

}
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$studentNumber = $_GET["studentNo"];

$sql = "SELECT students.Title, students.LastName, students.FirstName, 
        students.ID_No, students.StudentNo, students.Gender, applications.AppStatus, applications.ApplDate";

if (getstatus($studentNumber,$conn) ==="Accepted") {
    $sql .= ", residence.ResidenceName, rooms.RoomNo, building.BuildingNo";
}

$sql .= " FROM students
        JOIN applications ON students.ApplicationNo = applications.ApplicationNo";

if (getstatus($studentNumber,$conn)=== "Accepted") {
    $sql .= " JOIN rooms ON applications.RoomNo = rooms.RoomNo
              JOIN building ON rooms.BuildingNo = building.BuildingNo
              JOIN residence ON building.ResidenceNo = residence.ResidenceNo";
}

$sql .= " WHERE students.StudentNo = $studentNumber";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $studentData = $result->fetch_assoc();
    $conn->close();
    $title = $studentData["Title"];
    $lastName = $studentData["LastName"];
    $firstName = $studentData["FirstName"];
    $id = $studentData["ID_No"];
    $studentNo = $studentData["StudentNo"];
    $gender = $studentData["Gender"];
    $appStatus = $studentData["AppStatus"];
    $appDate = $studentData["ApplDate"];
    $residenceName = isset($studentData["ResidenceName"]) ? $studentData["ResidenceName"] : "Not Found";
    $roomNo = isset($studentData["RoomNo"]) ? $studentData["RoomNo"] : "Not Found";
    $buildingNo = isset($studentData["BuildingNo"]) ? $studentData["BuildingNo"] : "Not Found";
} else {
    $conn->close();
    $title = "Not Found";
    $lastName = "Not Found";
    $firstName = "Not Found";
    $id = "Not Found";
    $studentNo = "Not Found";
    $gender = "Not Found";
    $appStatus = "Not Found";
    $appDate = "Not Found";
    $residenceName = "Not Found";
    $roomNo = "Not Found";
    $buildingNo = "Not Found";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Application Status</title>
    <link rel="stylesheet" href="../css/status.css">
    <script>
        function viewAllocationDetails() {
            alert("Residence Name: <?php echo $residenceName; ?>" +
                  "\nRoom No: <?php echo $roomNo; ?>" +
                  "\nBuilding No: <?php echo $buildingNo; ?>");
        }
    </script>
</head>
<body>
    <div class="container">
        <h2>Application Status</h2>
        <p>Student Number: <?php echo $studentNo; ?></p>
        <p>Title: <?php echo $title; ?></p>
        <p>Last Name: <?php echo $lastName; ?></p>
        <p>First Name: <?php echo $firstName; ?></p>
        <p>ID Number: <?php echo $id; ?></p>
        <p>Gender: <?php echo $gender; ?></p>
        <p>Application Status: <?php echo $appStatus; ?></p>
        <p>Application Date: <?php echo $appDate; ?></p>
        <p>
            <?php if ($appStatus == "Accepted"): ?>
                <label style="cursor: pointer; color: blue;" onclick="viewAllocationDetails()">View Allocation Details</label>
            <?php endif; ?>
        </p>
        <div class="form-buttons">
            <a href="../HTML/Home.html" class="rounded-rectangle-button">Logout</a>
        </div>
    </div>
</body>
</html>
