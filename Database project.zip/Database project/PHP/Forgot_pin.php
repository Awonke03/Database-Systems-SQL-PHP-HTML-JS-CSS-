<?php
// Establish a database connection
$servername = "localhost";
$username = "Thurlo";
$password = "1M2@3r4i5t6z";
$dbname = "resapplications";


$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve student data based on the provided ID number
$idNumber = $_GET['idNumber'];
$sql = "SELECT studentno, pin FROM students WHERE id_no= '$idNumber'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $studentData = array(
        'studentno' => $row['studentno'],
        'pin' => $row['pin']
    );
    $response = array(
        'success' => true,
        'student' => $studentData
    );
} else {
    $response = array(
        'success' => false
    );
}

header('Content-Type: application/json');
echo json_encode($response);

$conn->close();
?>
