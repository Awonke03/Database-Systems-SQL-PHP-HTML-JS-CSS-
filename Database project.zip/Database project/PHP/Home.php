<?php
session_start();

if (!isset($_SESSION['username'])) {
    header('Location: index.php');
    exit();
}

$role = $_SESSION['role'];
$username = $_SESSION['username'];
?>

<script>
    var username = "<?php echo $username; ?>";
    var role = "<?php echo $role; ?>";

    function showAlert() {
        alert("Hello, " + username + "!");
    }

    document.addEventListener("DOMContentLoaded", function () {
        document.getElementById("username").textContent = username;

        if (role === 'admin') {
            document.getElementById("privileges").textContent = "You have admin privileges.";
        } else {
            document.getElementById("privileges").textContent = "You have user privileges.";
        }
    });
</script>
