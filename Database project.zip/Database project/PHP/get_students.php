<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Display Students</title>
    <link rel="stylesheet" href="../css/delete_student.css">
</head>
<body>
    <h2>Students</h2>
    
    <?php
    $servername = "localhost";
    $username = "Awonke";
    $password = "!Wowo@0823";
    $dbname = "resapplications";

    // Create a database connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "SELECT StudentNo, LastName, FirstName, ID_No, Gender FROM students";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        echo '<div class="scroll-table">';
        echo '<table>';
        echo '<tr><th>Student Number</th><th>Last Name</th><th>First Name</th><th>ID Number</th><th>Gender</th></tr>';

        while($row = $result->fetch_assoc()) {
            echo '<tr>';
            echo '<td>'.$row["StudentNo"].'</td>';
            echo '<td>'.$row["LastName"].'</td>';
            echo '<td>'.$row["FirstName"].'</td>';
            echo '<td>'.$row["ID_No"].'</td>';
            echo '<td>'.$row["Gender"].'</td>';
            echo '</tr>';
        }

        echo '</table>';
        echo '</div>';
    } else {
        echo "No students found.";
    }

    $conn->close();
    ?>
</body>
</html>
