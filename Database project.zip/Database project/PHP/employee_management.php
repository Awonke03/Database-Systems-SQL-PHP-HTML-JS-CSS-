<?php
$servername = "localhost";
$username = "Awonke";
$password = "!Wowo@0823";
$dbname = "resapplications";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST['insert_employee'])) {
    $title = $_POST['title'];
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $id_no = $_POST['id_no'];
    $gender = $_POST['gender'];
    $cell_number = $_POST['cell_number'];
    $email = $_POST['email'];
    $occupation = $_POST['occupation'];
    $residence_name = $_POST['residence_name'];

    $sql = "INSERT INTO employees (Title, FirstName, LastName, ID_No, Gender, cell_number, email, occupation, ResidenceName) 
            VALUES ('$title', '$first_name', '$last_name', '$id_no', '$gender', '$cell_number', '$email', '$occupation', '$residence_name')";

    if ($conn->query($sql) === TRUE) {
        echo "Employee inserted successfully.";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

if (isset($_POST['delete_employee'])) {
    $employeeNo = $_POST['employeeNo'];

    $sql = "DELETE FROM employees WHERE EmployeeNo = $employeeNo";

    if ($conn->query($sql) === TRUE) {
        echo "Employee deleted successfully.";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>
