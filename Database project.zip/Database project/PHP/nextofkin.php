<?php
session_start();

$servername = "localhost";
$username = "Thurlo";
$password = "1M2@3r4i5t6z";
$dbname = "resapplications";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $firstname = $_POST["firstname"];
    $lastname = $_POST["lastname"];
    $id_number = $_POST["id_number"];
    $cell_number = $_POST["cell_number"];
    $email = $_POST["email"];
    $relationship = $_POST["relationship"];
    $Title = $_POST["Title"];

    // Validate form data
    if (empty($firstname) || empty($lastname) || empty($id_number) || empty($cell_number) || empty($relationship)) {
        echo "All fields are required.";
    } elseif (!is_numeric($id_number) || strlen($id_number) !== 13) {
        echo "ID Number should be numeric and exactly 13 digits.";
    } elseif (!preg_match('/^0[6-8]\d{8}$/', $cell_number)) {
        echo "Cell Phone Number should start with '0' and be followed by 9 digits.";
    } else {
        // Generate gender based on the 7th character of ID number
        $gender = ($id_number[6] >= 5) ? "M" : "F";

        // Retrieve the student_number from the session
        if (isset($_SESSION['student_number'])) {
            $student_number = $_SESSION['student_number'];

            $id_number_exists = "SELECT * FROM nextofkin WHERE ID_No='$id_number'";
            $result = $conn->query($id_number_exists);

            if ($result === false) {
                echo "Error: " . $conn->error;
            } else {
                if ($result->num_rows > 0) {
                    echo "<script>alert('Next of Kin with this ID Number already exists.'); window.location.href = '../html/nextofkin.html';</script>";
                    exit;
                } else {
                    $sql = "INSERT INTO nextofkin (FirstName, LastName, ID_No, Gender, cell_number, email, Relationship, StudentNo, Title) 
                            VALUES ('$firstname', '$lastname', '$id_number', '$gender', '$cell_number', '$email', '$relationship', '$student_number', '$Title')";

                    if ($conn->query($sql) === TRUE) {
                        // Display a success message using JavaScript
                        echo "<script>alert('Data saved successfully.'); window.location.href = '../html/Confirmation.html';</script>";
                        exit;
                    } else {
                        echo "Error: " . $sql . "<br>" . $conn->error;
                    }
                }
            }
        } else {
            echo "Student Number not found in session.";
        }
    }
}

$conn->close();
?>
