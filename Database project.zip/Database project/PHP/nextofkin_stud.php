<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Information</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <h1>Student Information</h1>
        <a href="../htm/AdminPage.html">Back</a> <!-- Back button -->
        <div id="studentInfo">
            <?php
            // Database connection
            $servername = "localhost";
            $username = "Awonke";
            $password = "!Wowo@0823";
            $dbname = "RESAPPLICATIONS";

            $conn = new mysqli($servername, $username, $password, $dbname);

            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            $sql = "SELECT students.student_no, students.id_no, students.first_name as student_first_name, students.last_name as student_last_name, nextofkin.id_no as kin_id_no, 
            nextofkin.first_name as kin_first_name, nextofkin.last_name as kin_last_name, nextofkin.email, 
            nextofkin.cell_no FROM students INNER JOIN nextofkin ON students.id_no = nextofkin.id_no";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    echo "<div class='studentInfoCard'>";
                    echo "<h2>Student Info</h2>";
                    echo "<p>Student No: " . $row["student_no"]. "</p>";
                    echo "<p>ID No: " . $row["id_no"]. "</p>";
                    echo "<p>First Name: " . $row["student_first_name"]. "</p>";
                    echo "<p>Last Name: " . $row["student_last_name"]. "</p>";
                    echo "<div class='nextOfKinCard'>";
                    echo "<h2>Next of Kin</h2>";
                    echo "<p>ID No: " . $row["kin_id_no"]. "</p>";
                    echo "<p>First Name: " . $row["kin_first_name"]. "</p>";
                    echo "<p>Last Name: " . $row["kin_last_name"]. "</p>";
                    echo "<p>Email: " . $row["email"]. "</p>";
                    echo "<p>Cell No: " . $row["cell_no"]. "</p>";
                    echo "</div>";
                    echo "</div>";
                }
            } else {
                echo "0 results";
            }

            $conn->close();
            ?>
        </div>
    </div>
    <script src="script.js"></script>
</body>
</html>
