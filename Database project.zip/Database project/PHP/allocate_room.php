<?php
$servername = "localhost";
$username = "Awonke";
$password = "!Wowo@0823";
$dbname = "resapplications";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$data = json_decode(file_get_contents("php://input"));
$selectedRoom = $data->RoomNo;

$query = "SELECT ApplicationNo FROM Applications WHERE RoomNo IS NULL ORDER BY ApplicationNo LIMIT 1";
$result = mysqli_query($conn, $query);
$row = mysqli_fetch_assoc($result);
$ApplicationNo = $row["ApplicationNo"];

if ($ApplicationNo) {
    $updateQuery = "UPDATE Applications SET Roomno = '$selectedRoom', AppStatus = 'Allocated' WHERE ApplicationNo = $ApplicationNo";
    $updateResult = mysqli_query($conn, $updateQuery);

    $updateRoomQuery = "UPDATE Rooms SET available = 1 WHERE RoomNo = '$selectedRoom'";
    $updateRoomResult = mysqli_query($conn, $updateRoomQuery);

    if ($updateResult && $updateRoomResult) {
        echo json_encode(["success" => true]);
    } else {
        echo json_encode(["success" => false]);
    }
} else {
    echo json_encode(["success" => false]);
}

$conn->close();
?>
