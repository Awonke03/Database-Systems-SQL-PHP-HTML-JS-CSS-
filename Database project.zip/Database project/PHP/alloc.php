<?php

$servername = "localhost";
$username = "Awonke";
$password = "!Wowo@0823";
$dbname = "resapplications";

// Create a database connection
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$data = [
    "applications" => getApplications(),
    "rooms" => getRooms(),
];

echo json_encode($data);

function getApplications() {
    global $conn;
    $sql = "SELECT ApplicationNo FROM applications WHERE AppStatus = 'Under Review'";
    $result = $conn->query($sql);
    $applications = [];

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $applications[] = $row;
        }
    }

    return $applications;
}

function getRooms() {
    global $conn;
    $sql = "SELECT RoomNo FROM rooms WHERE Status > 0";
    $result = $conn->query($sql);
    $rooms = [];

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $rooms[] = $row;
        }
    }

    return $rooms;
}

$conn->close();
?>


