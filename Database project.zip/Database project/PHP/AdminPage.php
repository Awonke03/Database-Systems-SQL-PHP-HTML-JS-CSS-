<!DOCTYPE html>
<html>
<head>
	<meta charset = "utf-8">
	<meta name="viewport" content = "width- device-width , initial-scale=1.0">
    <title>Admin Page</title>
    <link rel="stylesheet" href="../css/AP.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" charset= "utf-8"></script>
</head>

<body>
	<div class = "side-bar">
		<div class= "menu">
		
				<div class="item">
					<a class="sub-btn"><i class="fas fa-table"></i> Student<i class= "fas fa-angle-right dropdown"></i></a>

					<div class="sub-menu-1">						
						<a href = "StudentOption.php" >Delete</a>
						<a href = "#"> Allocate</a>
						<a href = "#" >Maintain</a>	
					</div>
				</div>

			
				<div class="item">
					<a class="sub-btn"><i class="fas fa-table"></i> Employee<i class= "fas fa-angle-right dropdown"></i></a>

					<div class="sub-menu-1">						
						<a href = "#" >Add</a>
						<a href = "#" >Delete</a>
						
					</div>
					<div class="item"><a href="#"><i class="fas fa-desktop"></i>Residences</a></div>
					<div class="sub-menu-1">						
						<a href = "#" >Residence</a>
						<a href = "#" >Rooms</a>
						
					</div>
					
					<div class="item"><a href="#"><i class="fas fa-table"></i>Sign Out</a></div>
				</div>
	
		</div>
	</div>


</div>


	<script type= "text/javascript">
		$(document).ready(function(){
			//Query for toggle sub menus
			$(".sub-btn").click(function(){
				$(this).next(".sub-menu-1").slideToggle();
				$(this).find(".dropdown").toggleClass("rotate");
			});
		});
	</script>

</body>

</html>



</div>