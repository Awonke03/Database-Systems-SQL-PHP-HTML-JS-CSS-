<?php
$servername = "localhost";
$username = "Thurlo";
$password = "1M2@3r4i5t6z";
$dbname = "resapplications";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = $_POST["title"];
    $firstname = ucfirst($_POST["firstname"]); // Convert first letter to uppercase
    $lastname = ucfirst($_POST["lastname"]);  // Convert first letter to uppercase
    $id_number = $_POST["id_number"];
    $student_number = $_POST["student_number"];
    $cell_phone = $_POST["cell_phone"];
    $pin = $_POST["pin"];
    $confirm_pin = $_POST["confirm_pin"];
    $email = $student_number . "@spu.ac.za";
   

  

    $numericFields = array(
        'id_number' => $id_number,
        'student_number' => $student_number,
        'cell_phone' => $cell_phone,
        'pin' => $pin,
        'confirm_pin' => $confirm_pin
    );

    foreach ($numericFields as $field => $value) {
        if (!is_numeric($value)) {
            echo "<script>alert('$field should be numeric.');</script>";
            echo "<script>document.getElementById('$field').style.border = '1px solid red';</script>";
            echo "<script>window.location.href = '../html/signup.html';</script>";
            $conn->close();
            return;
        }
    }

    if (strlen($pin) !== 5) {
        echo "<script>alert('PIN should be exactly 5 digits.');</script>";
        echo "<script>document.getElementById('pin').style.border = '1px solid red';</script>";
        echo "<script>window.location.href = '../html/signup.html';</script>";
        $conn->close();
        return;
    }

    if (empty($title) || empty($firstname) || empty($lastname) || empty($id_number) ||
        empty($student_number) || empty($cell_phone) || empty($pin) || empty($confirm_pin) || empty($email) ) {
        echo "<script>alert('Please fill in all fields.');</script>";
        echo "<script>document.getElementById('signup-form').reset();</script>";
        $conn->close();
        return;
    } elseif ($pin !== $confirm_pin) {
        echo "<script>alert('PINs do not match.');</script>";
        echo "<script>document.getElementById('confirm_pin').style.border = '1px solid red';</script>";
        echo "<script>window.location.href = '../html/signup.html';</script>";
        $conn->close();
        return;
    } elseif (!preg_match('/^\d{13}$/', $id_number)) {
        echo "<script>alert('ID Number should be a 13-digit number.');</script>";
        echo "<script>document.getElementById('id_number').style.border = '1px solid red';</script>";
        echo "<script>window.location.href = '../html/signup.html';</script>";
        $conn->close();
        return;
    } elseif (!preg_match('/^\d{9}$/', $student_number)) {
        echo "<script>alert('Student Number should be a 9-digit number.');</script>";
        echo "<script>document.getElementById('student_number').style.border = '1px solid red';</script>";
        echo "<script>window.location.href = '../html/signup.html';</script>";
        $conn->close();
        return;
    } elseif (!preg_match('/^0\d{9}$/', $cell_phone)) {
        echo "<script>alert('Cell Phone Number should start with \"0\" and be followed by 9 digits.');</script>";
        echo "<script>document.getElementById('cell_phone').style.border = '1px solid red';</script>";
        echo "<script>window.location.href = '../html/signup.html';</script>";
        $conn->close();
        return;
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "<script>alert('Invalid email address.');</script>";
        echo "<script>document.getElementById('student_number').style.border = '1px solid red';</script>";
        echo "<script>window.location.href = '../html/signup.html';</script>";
        $conn->close();
        return;
    } else {
        $gender = ($id_number[6] >= 5) ? "M" : "F";
        $current_date = date("Y-m-d");
        $appstatus = "Under review";
        $room_number = 0;

        $id_check_sql = "SELECT * FROM students WHERE id_no='$id_number'";
        $student_check_sql = "SELECT * FROM students WHERE studentno='$student_number'";

        $id_result = $conn->query($id_check_sql);
        $student_result = $conn->query($student_check_sql);

        if ($id_result->num_rows > 0) {
            echo "<script>alert('ID Number already exists. Please choose a different one.');</script>";
            echo "<script>document.getElementById('id_number').style.border = '1px solid red';</script>";
            echo "<script>window.location.href = '../html/signup.html';</script>";
            $conn->close();
            return;
        }

        if ($student_result->num_rows > 0) {
            echo "<script>alert('Student Number already exists. Please choose a different one.');</script>";
            echo "<script>document.getElementById('student_number').style.border = '1px solid red';</script>";
            echo "<script>window.location.href = '../html/signup.html';</script>";
            $conn->close();
            return;
        }

        $sql = "INSERT INTO applications (appldate, appstatus, roomno) 
                VALUES ('$current_date', '$appstatus', $room_number)";

        if ($conn->query($sql) === TRUE) {
            $application_id = $conn->insert_id;

            $sql = "INSERT INTO students (applicationno, title, firstname, lastname, id_no, 
                    studentno, cell_number, email, pin,  gender)
                    VALUES ($application_id, '$title', '$firstname', '$lastname', '$id_number', 
                    '$student_number', '$cell_phone', '$email', '$pin', '$gender')";

            if ($conn->query($sql) === TRUE) {
               echo "<script>alert('Record added successfully.'); window.location.href = '../html/nextofkin.html?student_number=$student_number';</script>";
            } else {
                echo "<script>alert('Error: " . $sql . "\\n" . $conn->error . "');</script>";
                echo "<script>window.location.href = '../html/signup.html';</script>";
            }
        } else {
            echo "<script>alert('Error: " . $sql . "\\n" . $conn->error . "');</script>";
            echo "<script>window.location.href = '../html/signup.html';</script>";
        }
    }
}
session_start();


if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $student_number = $_POST["student_number"];
    
    $_SESSION['student_number'] = $student_number;

    header("Location: ../html/nextofkin.html");
    exit;
}


$conn->close();
?>
