<?php
session_start();

$servername = "localhost";
$username = "Thurlo";
$password = "1M2@3r4i5t6z";
$dbname = "resapplications";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $studentNumber = $_POST['student_number'];
    $pin = $_POST['pin'];

    $studentNumber = $conn->real_escape_string($studentNumber);
    $pin = $conn->real_escape_string($pin);

    $sql = "SELECT * FROM students WHERE StudentNo='$studentNumber' AND pin='$pin'";

    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $_SESSION['user_details'] = $row;
        echo json_encode(array('success' => true, 'student_details' => $row));
    } else {
        echo json_encode(array('success' => false));
    }
}

$conn->close();
?>
