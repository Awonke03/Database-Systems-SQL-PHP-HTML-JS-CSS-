<?php
$servername = "localhost";
$username = "Awonke";
$password = "!Wowo@0823";
$dbname = "resapplications";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_GET['getResidenceNames'])) {
    $residenceNo = getResidenceNames();
    echo json_encode($residenceNo);
} elseif (isset($_GET['getEmployees'])) {
    $employees = getEmployees();
    echo json_encode($employees);
}

function getResidenceNames() {
    global $conn;
    $sql = "SELECT ResidenceNo FROM residence";
    $result = $conn->query($sql);
    $residenceNo = [];

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $residenceNo[] = $row['ResidenceNo'];
        }
    }

    return $residenceNo;
}

function getEmployees() {
    global $conn;
    $sql = "SELECT * FROM employees";
    $result = $conn->query($sql);
    $employees = [];

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $employees[] = $row;
        }
    }

    return $employees;
}

if (isset($_POST['Title'])) {
    $title = $_POST['Title'];
    $firstName = $_POST['FirstName'];
    $lastName = $_POST['LastName'];
    $Id_No = $_POST['ID_No'];
    $Gender = $_POST['Gender'];
    $cell_number = $_POST['cell_number'];
    $email = $_POST['email'];
    $occupation = $_POST['occupation'];
    $residenceName = $_POST['ResidenceNo'];

    $sql = "INSERT INTO employees (Title, FirstName, LastName, ID_No, Gender, cell_number, email, occupation, ResidenceNo) 
            VALUES ('$title', '$firstName', '$lastName', '$Id_No', '$Gender', '$cell_number', '$email', '$occupation', '$residenceName')";

    if ($conn->query($sql) === TRUE) {
        echo "Employee inserted successfully.";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>
