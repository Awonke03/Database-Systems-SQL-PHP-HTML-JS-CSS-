<?php
// Establish a database connection (replace with your database connection details)
$servername = "localhost";
$username = "Awonke";
$password = "!Wowo@0823";
$dbname = "resapplications";


$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$query = "SELECT RoomNo, available FROM Rooms";
$result = $conn->query($query);

if ($result) {
    $rooms = array();

    while ($row = $result->fetch_assoc()) {
        $rooms[] = $row;
    }

    echo json_encode($rooms);
} else {
    echo json_encode(["error" => $conn->error]);
}

$conn->close();
?>
