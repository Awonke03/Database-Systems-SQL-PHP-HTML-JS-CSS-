<?php

$servername = "localhost";
$username = "Awonke";
$password = "!Wowo@0823";
$dbname = "resapplications";

// Create a database connection
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to fetch residences from the database
function getResidences() {
    global $conn;
    $sql = "SELECT * FROM residences";
    $result = $conn->query($sql);
    $residences = [];

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $residences[] = $row;
        }
    }

    return $residences;
}

// Function to add a residence to the database
function addResidence($data) {
    global $conn;
    $stmt = $conn->prepare("INSERT INTO residences (ResidenceName, streetAddress, city, province, postal_code) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $data["ResidenceName"], $data["streetAddress"], $data["city"], $data["province"], $data["postal_code"]);

    if ($stmt->execute()) {
        return true;
    } else {
        return false;
    }
}

// Handle incoming requests
if ($_SERVER["REQUEST_METHOD"] === "GET" && isset($_GET["action"])) {
    if ($_GET["action"] === "getResidences") {
        $residences = getResidences();
        echo json_encode($residences);
    }
} else ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["action"])) {
    if ($_POST["action"] === "addResidence") {
        $data = $_POST;
        if (addResidence($data)) {
            echo "Residence added successfully.";
        } else {
            echo "Error adding residence.";
        }
    } 
}

$conn->close();
