<?php
$servername = "localhost";
$username = "Awonke";
$password = "!Wowo@0823";
$dbname = "resapplications";

// Create a database connection
$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $studentNo = $_POST["studentNo"];

    // Check if the student exists
    $checkSql = "SELECT * FROM students WHERE StudentNo = '$studentNo'";
    $checkResult = $conn->query($checkSql);

    if ($checkResult->num_rows > 0) {
        // Find the ApplicationNo associated with the student
        $applicationNoSql = "SELECT ApplicationNo FROM students WHERE StudentNo = '$studentNo'";
        $applicationNoResult = $conn->query($applicationNoSql);

        if ($applicationNoResult->num_rows > 0) {
            $applicationNoRow = $applicationNoResult->fetch_assoc();
            $applicationNo = $applicationNoRow["ApplicationNo"];

            // Find the RoomNo associated with the application
            $roomNoSql = "SELECT RoomNo FROM applications WHERE ApplicationNo = '$applicationNo'";
            $roomNoResult = $conn->query($roomNoSql);

            if ($roomNoResult->num_rows > 0) {
                $roomNoRow = $roomNoResult->fetch_assoc();
                $roomNo = $roomNoRow["RoomNo"];

                // Increment the Status in the rooms table for the associated room
                $updateRoomStatusSql = "UPDATE rooms SET Status = Status + 1 WHERE RoomNo = '$roomNo'";
                $conn->query($updateRoomStatusSql);
            }

            // Delete the associated application
            $deleteApplicationSql = "DELETE FROM applications WHERE ApplicationNo = '$applicationNo'";
            $deleteApplicationResult = $conn->query($deleteApplicationSql);

            if ($deleteApplicationResult === TRUE) {
                // Now delete the student
                $deleteStudentSql = "DELETE FROM students WHERE StudentNo = '$studentNo'";
                $deleteStudentResult = $conn->query($deleteStudentSql);

                if ($deleteStudentResult === TRUE) {
                    echo "Student and associated application(s) deleted successfully.";
                } else {
                    echo "Error deleting student: " . $conn->error;
                }

            
            } else {
                echo "Error deleting associated application: " . $conn->error;
            }
        } else {
            echo "No associated application found.";
        }
    } else {
        echo "Student not found.";
    }
}

$conn->close();
?>
