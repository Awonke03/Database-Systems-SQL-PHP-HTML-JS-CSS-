<?php
$servername = "localhost";
$username = "Awonke";
$password = "!Wowo@0823";
$dbname = "resapplications";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_GET["getBuildings"])) {
    $buildings = getBuildings();
    echo json_encode($buildings);
}

if (isset($_GET["getResidence"])) {
    $residence = getResidence();
    echo json_encode($residence);
}

function getBuildings() {
    global $conn;
    $sql = "SELECT * FROM building";
    $result = $conn->query($sql);
    $buildings = [];

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $buildings[] = $row;
        }
    }

    return $buildings;
}

function getResidence() {
    global $conn;
    $sql = "SELECT ResidenceNo FROM residence";
    $result = $conn->query($sql);
    $residence = [];

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $residence[] = $row;
        }
    }

    return $residence;
}

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["Capacity"])) {
    $data = $_POST;
    echo addBuilding($data);
} elseif ($_SERVER["REQUEST_METHOD"] === "DELETE" && isset($_GET["deleteBuilding"])) {
    $BuildingNo = $_GET["deleteBuilding"];
    echo deleteBuilding($BuildingNo);
}

function addBuilding($data) {
    global $conn;
    $stmt = $conn->prepare("INSERT INTO building (Capacity, ResidenceNo) VALUES (?, ?)");
    $stmt->bind_param("ii", $data["Capacity"], $data["ResidenceNo"]);

    if ($stmt->execute()) {
        return "Building added successfully.";
    } else {
        return "Error adding building.";
    }
}

function deleteBuilding($BuildingNo) {
    global $conn;

    // Delete rooms with matching BuildingNo
    $stmtDeleteRooms = $conn->prepare("DELETE FROM rooms WHERE BuildingNo = ?");
    $stmtDeleteRooms->bind_param("i", $BuildingNo);

    // Delete the building
    $stmtDeleteBuilding = $conn->prepare("DELETE FROM building WHERE BuildingNo = ?");
    $stmtDeleteBuilding->bind_param("i", $BuildingNo);

    if ($stmtDeleteRooms->execute() && $stmtDeleteBuilding->execute()) {
        return "Building and associated rooms deleted successfully.";
    } else {
        return "Error deleting building and associated rooms.";
    }
}

$conn->close();
?>
